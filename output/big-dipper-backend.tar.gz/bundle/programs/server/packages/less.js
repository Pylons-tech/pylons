(function () {



/* Exports */
Package._define("less");

})();
